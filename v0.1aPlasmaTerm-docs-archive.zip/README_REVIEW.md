# README review

The current README is already concise and its tone suits the project. Only
three material changes are recommended.

## 1. Add the actual runtime target and start command

This is important because keyboard input is Windows-specific and the README
currently provides no invocation.

Suggested text near the first paragraphs:

> Requires Python 3 on Windows and is designed for Windows Terminal. It uses
> only the Python standard library. Run it with `python plasma.py`.

## 2. Qualify which controls affect stored LUTs

The generated default uses `active-lut = 0`, so the hue-range and palette-size
controls update config but cannot visibly alter that stored LUT. A short note
after the controls table would prevent confusion:

> `hue-start`, `hue-end`, and `palette-size` affect the procedural palette only
> (`active-lut = none`). Stored LUTs contain exactly 256 colours.

## 3. Describe watched-file control precisely

“Applied instantly” overstates a per-frame file poll and implies suitability
for high-rate modulation. Replace that sentence with:

> Parameter changes are written to `plasma.conf` immediately. Valid external
> edits are picked up on the next frame; incomplete or invalid saves leave the
> last valid state running. This watched-file path is intended for low-rate
> automation rather than high-rate modulation.

No broader rewrite is recommended. The controls table, short project
description, image, bootstrap summary and generator summary are factually
consistent with this release.
